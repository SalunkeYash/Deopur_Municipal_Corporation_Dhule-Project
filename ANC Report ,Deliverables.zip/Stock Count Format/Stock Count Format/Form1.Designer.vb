﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Gray
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(113, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(505, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "                               Stock Count Format                                " &
    "  "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(114, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(167, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name of the Cold Chain Point"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(114, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "District"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(114, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(215, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Name and Designation of the Assessor"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(114, 155)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Date of Visit"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(379, 46)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(559, 22)
        Me.TextBox1.TabIndex = 5
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(379, 79)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(559, 22)
        Me.TextBox2.TabIndex = 6
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(379, 112)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(559, 22)
        Me.TextBox3.TabIndex = 7
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(379, 148)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(559, 22)
        Me.TextBox4.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(73, 24)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(111, 29)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Materials"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(638, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(138, 29)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Stock in RR"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(786, 10)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(104, 58)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Stock in Register"
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(925, 10)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(113, 58)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Stock in eVIN app"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(1071, 24)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(97, 29)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Remark"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 29)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 20)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "SR.NO"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 6
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.85973!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 89.14027!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 147.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 145.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 136.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox53, 5, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox52, 4, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox51, 3, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox50, 2, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox48, 5, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox47, 4, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox46, 3, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox45, 2, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox43, 5, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox42, 4, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox41, 3, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox40, 2, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox38, 5, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox37, 4, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox36, 3, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox35, 2, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox33, 5, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox32, 4, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox31, 3, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox30, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox28, 5, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox27, 4, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox26, 3, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox25, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox23, 5, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox22, 4, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox21, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox20, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox18, 5, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox17, 4, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox16, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox15, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox13, 5, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox12, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox11, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox10, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox7, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox6, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label10, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label16, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label17, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label18, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label19, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label24, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label25, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label26, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label27, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label28, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label29, 0, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.Label30, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label31, 1, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label32, 1, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox5, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox8, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 5, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(67, 202)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 11
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.2766!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.7234!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1206, 437)
        Me.TableLayoutPanel1.TabIndex = 9
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(4, 78)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(30, 25)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "1)"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(4, 109)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(30, 25)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "2)"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(4, 145)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(30, 25)
        Me.Label15.TabIndex = 10
        Me.Label15.Text = "3)"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(4, 182)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(30, 25)
        Me.Label16.TabIndex = 11
        Me.Label16.Text = "4)"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(4, 224)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(30, 25)
        Me.Label17.TabIndex = 12
        Me.Label17.Text = "5)"
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(73, 85)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(79, 16)
        Me.Label18.TabIndex = 13
        Me.Label18.Text = "BCG (Dose)"
        '
        'Label19
        '
        Me.Label19.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(73, 118)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(133, 16)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "BCG Difluents (Dose)"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(73, 155)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(87, 16)
        Me.Label20.TabIndex = 15
        Me.Label20.Text = "bOPV (Dose)"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(73, 194)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(104, 16)
        Me.Label21.TabIndex = 16
        Me.Label21.Text = "bOPV (Dropper)"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(73, 238)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(79, 16)
        Me.Label22.TabIndex = 17
        Me.Label22.Text = "DPT (Dose)"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(4, 269)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(30, 25)
        Me.Label23.TabIndex = 18
        Me.Label23.Text = "6)"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(4, 309)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(30, 25)
        Me.Label24.TabIndex = 19
        Me.Label24.Text = "7)"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(73, 280)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(122, 16)
        Me.Label25.TabIndex = 20
        Me.Label25.Text = "Pentavalent (Dose)"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(73, 319)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(86, 16)
        Me.Label26.TabIndex = 21
        Me.Label26.Text = "Hep.B(Dose)"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(4, 346)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(30, 25)
        Me.Label27.TabIndex = 22
        Me.Label27.Text = "8)"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(4, 380)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(30, 25)
        Me.Label28.TabIndex = 23
        Me.Label28.Text = "9)"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(4, 411)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(41, 25)
        Me.Label29.TabIndex = 24
        Me.Label29.Text = "10)"
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(73, 354)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(67, 16)
        Me.Label30.TabIndex = 25
        Me.Label30.Text = "JE (Dose)"
        '
        'Label31
        '
        Me.Label31.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(73, 387)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(115, 16)
        Me.Label31.TabIndex = 26
        Me.Label31.Text = "JE Diluents(Dose)"
        '
        'Label32
        '
        Me.Label32.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(73, 415)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(121, 16)
        Me.Label32.TabIndex = 27
        Me.Label32.Text = "MR Vaccine(Dose)"
        '
        'TextBox5
        '
        Me.TextBox5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox5.Location = New System.Drawing.Point(638, 82)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 22)
        Me.TextBox5.TabIndex = 28
        '
        'TextBox6
        '
        Me.TextBox6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox6.Location = New System.Drawing.Point(786, 82)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 22)
        Me.TextBox6.TabIndex = 29
        '
        'TextBox7
        '
        Me.TextBox7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox7.Location = New System.Drawing.Point(925, 82)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 22)
        Me.TextBox7.TabIndex = 30
        '
        'TextBox8
        '
        Me.TextBox8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox8.Location = New System.Drawing.Point(1071, 82)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 22)
        Me.TextBox8.TabIndex = 31
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(638, 112)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 22)
        Me.TextBox10.TabIndex = 33
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(786, 112)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(100, 22)
        Me.TextBox11.TabIndex = 34
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(925, 112)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(100, 22)
        Me.TextBox12.TabIndex = 35
        '
        'TextBox13
        '
        Me.TextBox13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox13.Location = New System.Drawing.Point(1071, 115)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(100, 22)
        Me.TextBox13.TabIndex = 36
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(638, 148)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(100, 22)
        Me.TextBox15.TabIndex = 38
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(786, 148)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(100, 22)
        Me.TextBox16.TabIndex = 39
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(925, 148)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(100, 22)
        Me.TextBox17.TabIndex = 40
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(1071, 148)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(100, 22)
        Me.TextBox18.TabIndex = 41
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(638, 185)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(100, 22)
        Me.TextBox20.TabIndex = 43
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(786, 185)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(100, 22)
        Me.TextBox21.TabIndex = 44
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(925, 185)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(100, 22)
        Me.TextBox22.TabIndex = 45
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(1071, 185)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(100, 22)
        Me.TextBox23.TabIndex = 46
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(638, 227)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(100, 22)
        Me.TextBox25.TabIndex = 48
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(786, 227)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(100, 22)
        Me.TextBox26.TabIndex = 49
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(925, 227)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(100, 22)
        Me.TextBox27.TabIndex = 50
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(1071, 227)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(100, 22)
        Me.TextBox28.TabIndex = 51
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(638, 272)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(100, 22)
        Me.TextBox30.TabIndex = 53
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(786, 272)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(100, 22)
        Me.TextBox31.TabIndex = 54
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(925, 272)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(100, 22)
        Me.TextBox32.TabIndex = 55
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(1071, 272)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(100, 22)
        Me.TextBox33.TabIndex = 56
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(638, 312)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(100, 22)
        Me.TextBox35.TabIndex = 58
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(786, 312)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(100, 22)
        Me.TextBox36.TabIndex = 59
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(925, 312)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(100, 22)
        Me.TextBox37.TabIndex = 60
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(1071, 312)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(100, 22)
        Me.TextBox38.TabIndex = 61
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(638, 349)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(100, 22)
        Me.TextBox40.TabIndex = 63
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(786, 349)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(100, 22)
        Me.TextBox41.TabIndex = 64
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(925, 349)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(100, 22)
        Me.TextBox42.TabIndex = 65
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(1071, 349)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(100, 22)
        Me.TextBox43.TabIndex = 66
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(638, 383)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(100, 22)
        Me.TextBox45.TabIndex = 68
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(786, 383)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(100, 22)
        Me.TextBox46.TabIndex = 69
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(925, 383)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(100, 22)
        Me.TextBox47.TabIndex = 70
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(1071, 383)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(100, 22)
        Me.TextBox48.TabIndex = 71
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(638, 414)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(100, 22)
        Me.TextBox50.TabIndex = 73
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(786, 414)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(100, 22)
        Me.TextBox51.TabIndex = 74
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(925, 414)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(100, 22)
        Me.TextBox52.TabIndex = 75
        '
        'TextBox53
        '
        Me.TextBox53.Location = New System.Drawing.Point(1071, 414)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(100, 22)
        Me.TextBox53.TabIndex = 76
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Gray
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(572, 650)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(119, 34)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "NEXT"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1380, 685)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TextBox53 As TextBox
    Friend WithEvents TextBox52 As TextBox
    Friend WithEvents TextBox51 As TextBox
    Friend WithEvents TextBox50 As TextBox
    Friend WithEvents TextBox48 As TextBox
    Friend WithEvents TextBox47 As TextBox
    Friend WithEvents TextBox46 As TextBox
    Friend WithEvents TextBox45 As TextBox
    Friend WithEvents TextBox43 As TextBox
    Friend WithEvents TextBox42 As TextBox
    Friend WithEvents TextBox41 As TextBox
    Friend WithEvents TextBox40 As TextBox
    Friend WithEvents TextBox38 As TextBox
    Friend WithEvents TextBox37 As TextBox
    Friend WithEvents TextBox36 As TextBox
    Friend WithEvents TextBox35 As TextBox
    Friend WithEvents TextBox33 As TextBox
    Friend WithEvents TextBox32 As TextBox
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents TextBox30 As TextBox
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Button1 As Button
End Class
