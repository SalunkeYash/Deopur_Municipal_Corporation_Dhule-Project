﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 6
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.85973!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 89.14027!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 147.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 145.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 136.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox38, 5, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox37, 4, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox36, 3, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox35, 2, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox33, 5, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox32, 4, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox31, 3, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox30, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox28, 5, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox27, 4, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox26, 3, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox25, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox23, 5, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox22, 4, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox21, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox20, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox18, 5, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox17, 4, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox16, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox15, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox13, 5, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox12, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox11, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox10, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox7, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox6, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label10, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label16, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label17, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label18, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label19, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label24, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label25, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label26, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox5, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox8, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 5, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(58, 51)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 8
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.60825!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.39175!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 67.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1206, 499)
        Me.TableLayoutPanel1.TabIndex = 10
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(1071, 443)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(100, 22)
        Me.TextBox38.TabIndex = 61
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(925, 443)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(100, 22)
        Me.TextBox37.TabIndex = 60
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(786, 443)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(100, 22)
        Me.TextBox36.TabIndex = 59
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(638, 443)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(100, 22)
        Me.TextBox35.TabIndex = 58
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(1071, 375)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(100, 22)
        Me.TextBox33.TabIndex = 56
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(925, 375)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(100, 22)
        Me.TextBox32.TabIndex = 55
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(786, 375)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(100, 22)
        Me.TextBox31.TabIndex = 54
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(638, 375)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(100, 22)
        Me.TextBox30.TabIndex = 53
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(1071, 320)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(100, 22)
        Me.TextBox28.TabIndex = 51
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(925, 320)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(100, 22)
        Me.TextBox27.TabIndex = 50
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(786, 320)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(100, 22)
        Me.TextBox26.TabIndex = 49
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(638, 320)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(100, 22)
        Me.TextBox25.TabIndex = 48
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(1071, 259)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(100, 22)
        Me.TextBox23.TabIndex = 46
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(925, 259)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(100, 22)
        Me.TextBox22.TabIndex = 45
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(786, 259)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(100, 22)
        Me.TextBox21.TabIndex = 44
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(638, 259)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(100, 22)
        Me.TextBox20.TabIndex = 43
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(1071, 188)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(100, 22)
        Me.TextBox18.TabIndex = 41
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(925, 188)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(100, 22)
        Me.TextBox17.TabIndex = 40
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(786, 188)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(100, 22)
        Me.TextBox16.TabIndex = 39
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(638, 188)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(100, 22)
        Me.TextBox15.TabIndex = 38
        '
        'TextBox13
        '
        Me.TextBox13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox13.Location = New System.Drawing.Point(1071, 138)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(100, 22)
        Me.TextBox13.TabIndex = 36
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(925, 117)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(100, 22)
        Me.TextBox12.TabIndex = 35
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(786, 117)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(100, 22)
        Me.TextBox11.TabIndex = 34
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(638, 117)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 22)
        Me.TextBox10.TabIndex = 33
        '
        'TextBox7
        '
        Me.TextBox7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox7.Location = New System.Drawing.Point(925, 76)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 22)
        Me.TextBox7.TabIndex = 30
        '
        'TextBox6
        '
        Me.TextBox6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox6.Location = New System.Drawing.Point(786, 76)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 22)
        Me.TextBox6.TabIndex = 29
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(638, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(138, 29)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Stock in RR"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(73, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(111, 29)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Materials"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(786, 2)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(104, 58)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Stock in Register"
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(925, 2)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(113, 58)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Stock in eVIN app"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 20)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "SR.NO"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(4, 75)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(41, 25)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "11)"
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(4, 136)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(41, 25)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "12)"
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(4, 207)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(41, 25)
        Me.Label15.TabIndex = 10
        Me.Label15.Text = "13)"
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(4, 273)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(41, 25)
        Me.Label16.TabIndex = 11
        Me.Label16.Text = "14)"
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(4, 331)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(41, 25)
        Me.Label17.TabIndex = 12
        Me.Label17.Text = "15)"
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(73, 79)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(123, 16)
        Me.Label18.TabIndex = 13
        Me.Label18.Text = "MR Diluents (Dose)"
        '
        'Label19
        '
        Me.Label19.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(73, 141)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(72, 16)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "IPV (Dose)"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(73, 212)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(69, 16)
        Me.Label20.TabIndex = 15
        Me.Label20.Text = "TT (Dose)"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(73, 278)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(152, 16)
        Me.Label21.TabIndex = 16
        Me.Label21.Text = "bOPV Campaign (Dose)"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(73, 336)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(161, 16)
        Me.Label22.TabIndex = 17
        Me.Label22.Text = "bOPV Campaign Dropper"
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(4, 393)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(41, 25)
        Me.Label23.TabIndex = 18
        Me.Label23.Text = "16)"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(4, 456)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(41, 25)
        Me.Label24.TabIndex = 19
        Me.Label24.Text = "17)"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(73, 397)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(192, 16)
        Me.Label25.TabIndex = 20
        Me.Label25.Text = " MR Vaccine Campaign (Dose)"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(73, 461)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(188, 16)
        Me.Label26.TabIndex = 21
        Me.Label26.Text = "MR Dilluents Campaign(Dose)"
        '
        'TextBox5
        '
        Me.TextBox5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox5.Location = New System.Drawing.Point(638, 76)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 22)
        Me.TextBox5.TabIndex = 28
        '
        'TextBox8
        '
        Me.TextBox8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox8.Location = New System.Drawing.Point(1071, 76)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 22)
        Me.TextBox8.TabIndex = 31
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(1071, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(97, 29)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Remark"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Gray
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(588, 589)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(194, 55)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "PREVIOUS"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1347, 673)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TextBox38 As TextBox
    Friend WithEvents TextBox37 As TextBox
    Friend WithEvents TextBox36 As TextBox
    Friend WithEvents TextBox35 As TextBox
    Friend WithEvents TextBox33 As TextBox
    Friend WithEvents TextBox32 As TextBox
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents TextBox30 As TextBox
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Button1 As Button
End Class
