﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(65, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(243, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Dhule Muncipal Corporation"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(65, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(236, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Monthly Reporting Formate"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(65, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Month:-"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(65, 109)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(156, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Name of UPHC :-"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 6
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.27119!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 83.72881!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 219.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 228.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 226.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 185.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox30, 4, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox29, 3, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox28, 2, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox26, 4, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox25, 3, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox24, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox22, 4, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox21, 3, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox20, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox18, 4, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox17, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox16, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox14, 4, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox13, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox12, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox10, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox9, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox8, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox6, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label16, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 5, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label27, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label26, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label24, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label25, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label19, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label18, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label17, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox5, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox7, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox11, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox15, 5, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox19, 5, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox23, 5, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox27, 5, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox31, 5, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox32, 5, 7)
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(38, 201)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 8
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 58.06452!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.93548!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1333, 428)
        Me.TableLayoutPanel1.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(541, 145)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(127, 25)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "ANC Report"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(337, 7)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(768, 22)
        Me.TextBox1.TabIndex = 6
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(337, 36)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(768, 22)
        Me.TextBox2.TabIndex = 7
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(337, 66)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(768, 22)
        Me.TextBox3.TabIndex = 8
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(337, 107)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(768, 22)
        Me.TextBox4.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 25)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "SR.No"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(81, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 25)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Indicators"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(473, 21)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 25)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Target"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(871, 173)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(126, 25)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Achievement"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(1149, 21)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(115, 25)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Progressive"
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(4, 79)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(30, 25)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "1)"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(81, 79)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(55, 25)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "ANC"
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(693, 21)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(144, 25)
        Me.Label14.TabIndex = 8
        Me.Label14.Text = "Private Institute"
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(922, 21)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(68, 25)
        Me.Label15.TabIndex = 9
        Me.Label15.Text = "UPHC"
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(4, 187)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(30, 25)
        Me.Label16.TabIndex = 10
        Me.Label16.Text = "3)"
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 131)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(30, 25)
        Me.Label17.TabIndex = 11
        Me.Label17.Text = "2)"
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(4, 244)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(30, 25)
        Me.Label18.TabIndex = 12
        Me.Label18.Text = "4)"
        '
        'Label19
        '
        Me.Label19.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(4, 298)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(30, 25)
        Me.Label19.TabIndex = 13
        Me.Label19.Text = "5)"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(4, 345)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(30, 25)
        Me.Label20.TabIndex = 14
        Me.Label20.Text = "6)"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(4, 391)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(30, 25)
        Me.Label21.TabIndex = 15
        Me.Label21.Text = "7)"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(81, 131)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(152, 25)
        Me.Label22.TabIndex = 16
        Me.Label22.Text = "12 th Week Reg"
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(81, 187)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(218, 25)
        Me.Label23.TabIndex = 17
        Me.Label23.Text = "4th Visit Check up ANC"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(81, 244)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(175, 25)
        Me.Label24.TabIndex = 18
        Me.Label24.Text = "Tab.Iron Folic Acid"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(81, 298)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(123, 25)
        Me.Label25.TabIndex = 19
        Me.Label25.Text = "Tab.Calcium"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(81, 345)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(135, 25)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "Inj.T.T.1 Dose"
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(81, 391)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(208, 25)
        Me.Label27.TabIndex = 21
        Me.Label27.Text = "Inj.T.T.2/Booster Dose"
        '
        'TextBox5
        '
        Me.TextBox5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox5.Location = New System.Drawing.Point(473, 76)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(147, 30)
        Me.TextBox5.TabIndex = 22
        '
        'TextBox6
        '
        Me.TextBox6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox6.Location = New System.Drawing.Point(693, 76)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(147, 30)
        Me.TextBox6.TabIndex = 23
        '
        'TextBox7
        '
        Me.TextBox7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox7.Location = New System.Drawing.Point(922, 76)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(147, 30)
        Me.TextBox7.TabIndex = 24
        '
        'TextBox8
        '
        Me.TextBox8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox8.Location = New System.Drawing.Point(473, 128)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(147, 30)
        Me.TextBox8.TabIndex = 25
        '
        'TextBox9
        '
        Me.TextBox9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox9.Location = New System.Drawing.Point(693, 128)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(147, 30)
        Me.TextBox9.TabIndex = 26
        '
        'TextBox10
        '
        Me.TextBox10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox10.Location = New System.Drawing.Point(922, 128)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(147, 30)
        Me.TextBox10.TabIndex = 27
        '
        'TextBox11
        '
        Me.TextBox11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox11.Location = New System.Drawing.Point(1149, 76)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(147, 30)
        Me.TextBox11.TabIndex = 28
        '
        'TextBox12
        '
        Me.TextBox12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox12.Location = New System.Drawing.Point(473, 185)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(147, 30)
        Me.TextBox12.TabIndex = 29
        '
        'TextBox13
        '
        Me.TextBox13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox13.Location = New System.Drawing.Point(693, 185)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(147, 30)
        Me.TextBox13.TabIndex = 30
        '
        'TextBox14
        '
        Me.TextBox14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox14.Location = New System.Drawing.Point(922, 185)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(147, 30)
        Me.TextBox14.TabIndex = 31
        '
        'TextBox15
        '
        Me.TextBox15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox15.Location = New System.Drawing.Point(1149, 128)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(147, 30)
        Me.TextBox15.TabIndex = 32
        '
        'TextBox16
        '
        Me.TextBox16.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox16.Location = New System.Drawing.Point(473, 242)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(147, 30)
        Me.TextBox16.TabIndex = 33
        '
        'TextBox17
        '
        Me.TextBox17.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox17.Location = New System.Drawing.Point(693, 242)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(147, 30)
        Me.TextBox17.TabIndex = 34
        '
        'TextBox18
        '
        Me.TextBox18.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox18.Location = New System.Drawing.Point(922, 242)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(147, 30)
        Me.TextBox18.TabIndex = 35
        '
        'TextBox19
        '
        Me.TextBox19.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox19.Location = New System.Drawing.Point(1149, 185)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(147, 30)
        Me.TextBox19.TabIndex = 36
        '
        'TextBox20
        '
        Me.TextBox20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox20.Location = New System.Drawing.Point(473, 295)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(147, 30)
        Me.TextBox20.TabIndex = 37
        '
        'TextBox21
        '
        Me.TextBox21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox21.Location = New System.Drawing.Point(693, 295)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(147, 30)
        Me.TextBox21.TabIndex = 38
        '
        'TextBox22
        '
        Me.TextBox22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox22.Location = New System.Drawing.Point(922, 295)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(147, 30)
        Me.TextBox22.TabIndex = 39
        '
        'TextBox23
        '
        Me.TextBox23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox23.Location = New System.Drawing.Point(1149, 242)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(147, 30)
        Me.TextBox23.TabIndex = 40
        '
        'TextBox24
        '
        Me.TextBox24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox24.Location = New System.Drawing.Point(473, 343)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(147, 30)
        Me.TextBox24.TabIndex = 41
        '
        'TextBox25
        '
        Me.TextBox25.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox25.Location = New System.Drawing.Point(693, 343)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(147, 30)
        Me.TextBox25.TabIndex = 42
        '
        'TextBox26
        '
        Me.TextBox26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox26.Location = New System.Drawing.Point(922, 343)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(147, 30)
        Me.TextBox26.TabIndex = 43
        '
        'TextBox27
        '
        Me.TextBox27.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox27.Location = New System.Drawing.Point(1149, 295)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(147, 30)
        Me.TextBox27.TabIndex = 44
        '
        'TextBox28
        '
        Me.TextBox28.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox28.Location = New System.Drawing.Point(473, 389)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(147, 30)
        Me.TextBox28.TabIndex = 45
        '
        'TextBox29
        '
        Me.TextBox29.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox29.Location = New System.Drawing.Point(693, 389)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(147, 30)
        Me.TextBox29.TabIndex = 46
        '
        'TextBox30
        '
        Me.TextBox30.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox30.Location = New System.Drawing.Point(922, 389)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(147, 30)
        Me.TextBox30.TabIndex = 47
        '
        'TextBox31
        '
        Me.TextBox31.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox31.Location = New System.Drawing.Point(1149, 343)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(147, 30)
        Me.TextBox31.TabIndex = 48
        '
        'TextBox32
        '
        Me.TextBox32.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox32.Location = New System.Drawing.Point(1149, 389)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(147, 30)
        Me.TextBox32.TabIndex = 49
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1402, 641)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label9)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Label16 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox30 As TextBox
    Friend WithEvents TextBox29 As TextBox
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents TextBox24 As TextBox
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents TextBox32 As TextBox
End Class
